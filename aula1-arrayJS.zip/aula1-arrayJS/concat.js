var vetor1 = new Array(1, 2, 3)
var vetor2 = new Array(4, 5, 6)
var vetor3 = new Array(7, 8, 9)
var result = vetor1.concat(vetor2, vetor3)

console.log(result)