// Este método copia uma parte dada de um array e retorna aquela parte copiada como um novo array. Ele não altera o array original.

let numeros = [1, 2, 3, 4]
numeros.slice(0, 3)

// retorna [1, 2, 3]
console.log(numeros) // retorna o array original