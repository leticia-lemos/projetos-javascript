let agenda = ['Eu', 'tenho', 'um', 'compromisso', 'amanhã']

// remove os 4 primeiros elementos e os substitui por outros
agenda.splice(0, 4, 'Nós', 'vamos', 'nadar')
console.log(agenda)