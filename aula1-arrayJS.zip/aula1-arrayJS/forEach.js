var alunos = ["Gabrielly", "Maria", "Sarah", "Ana", "Carlos"]

alunos.forEach(function(estudante){
    console.log("Este(a) aluno(a) é do curso de informática: " + estudante + '${<br>}')
})