// O método toString() em JavaScript converte um array em uma string separada por vírgulas

let cores = ['verde', 'amarelo', 'azul']

console.log(cores.toString()) 