let nome = 'Leticia'

// retorna a string como um array
nome.split() // [leticia]
console.log(nome)