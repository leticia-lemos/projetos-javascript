let agenda = ['Eu', 'tenho', 'um', 'compromisso', 'com']

agenda.splice(5, 0, 'alguns', 'clientes', 'amanhã')
console.log(agenda)