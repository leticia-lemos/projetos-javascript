var nomes = ["Sergio", "Maria", "Yasmin", "Yasmin", "Richard", "Bia", "Camila"]

var indicesNomes = nomes.indexOf("Yasmin")
console.log(indicesNomes)

/*
var indicesNomes = nomes.indexOf("Andre")
console.log(indicesNomes)
*/