// Este método adiciona um ou vários itens ao início de um array e altera o array original

let frutas = ['banana', 'maçã', 'morango']
frutas.unshift('mamão')