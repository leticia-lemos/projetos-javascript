function somar(num1, num2) {
    return num1 + num2
}

var resultado = somar(3, 5)
console.log('resultado 1: ' + resultado)

function nome(nome, sobrenome) {
    return nome + sobrenome
}

var nomeCompleto = nome('Leticia ', 'Lemos')
console.log('resultado 2: ' + nomeCompleto)