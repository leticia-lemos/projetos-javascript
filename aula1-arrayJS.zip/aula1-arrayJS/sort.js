var ordenarNum = [8, 15, 1, 7, 2, 90, 3]
console.log(ordenarNum.sort())