// O método join() em JavaScript combina todos os elementos do array em uma string.
// Ele é semelhante ao método toString(), mas, aqui, você pode especificar o separador em vez da vírgula padrão.

let cores = ['verde', 'amarelo', 'azul']

console.log(cores.join('-')) 