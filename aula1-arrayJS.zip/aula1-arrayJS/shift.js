// Este método remove o primeiro item de um array e o retorna

let carros = ['gol', 'palio', 'corsa']
carros.shift()
console.log(carros)