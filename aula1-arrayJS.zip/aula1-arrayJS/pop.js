// Este método remove o último item de um array e o retorna

var lista = ['arroz', 'feijão', 'acúçar', 'café', 'chocolate']
console.log(lista)

// incrementar a lista adicionando um elemento no final do array: Método push()

lista.pop()
console.log(lista)