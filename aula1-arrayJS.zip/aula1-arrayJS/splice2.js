// Este método altera um array, adicionando, removendo e inserindo elementos

let cores = ['verde', 'ammarelo', 'azul', 'roxo']
cores.splice(3)
console.log(cores)