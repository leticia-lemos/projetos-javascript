// Este método altera um array, adicionando, removendo e inserindo elementos

let frutas = ['banana', 'maçã', 'morango', 'mamão', 'uva']
frutas.splice(0,3)
console.log(frutas)