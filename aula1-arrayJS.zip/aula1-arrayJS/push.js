// Este método adiciona itens ao final de um array e altera o array original

var lista = ['arroz', 'feijão', 'acúçar', 'café', 'chocolate']
console.log(lista)

// incrementar a lista adicionando um elemento no final do array: Método push()

lista.push('iogurte', 'macarrão')
console.log(lista)